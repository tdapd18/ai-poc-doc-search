# 계리 업무자료 AI 통합검색 PoC — 전달 패키지

교육용 PoC(가상 더미데이터만 사용, 실제 사내 시스템·외부 API 미연결, 실제 LLM 미연결·Mock만 제공)

## 구성
| 경로 | 내용 |
|---|---|
| `ai-poc-doc-search/` (저장소 루트와 동일) | 프로젝트 전체 (Streamlit 앱, Connector, 검색/권한/동기화/RAG 코어, 가상 데이터, 테스트, 문서) |
| `README.md` | Windows 기준 설치·실행·테스트 방법 |
| `README_DEMO.md` | 시연 시나리오, 수동 테스트 체크리스트 |
| `docs/DESIGN.md` | 설계·점수 규칙·보안·사내망 연동 시 추가 필요사항 |
| `docs/TEST_RESULTS.md` | 자동 테스트 결과표 (141건 통과) |
| `docs/screenshot_search.png` | 화면 캡처 |
| `web_demo/index.html` | 정적 웹 시연판 (브라우저로 바로 열기, 게시 링크와 동일 내용) |
| `tools/` (프로젝트 내) | 샘플 PDF/Excel/PPT 생성기, 웹 시연판 빌더 |

## 빠른 실행 (Windows PowerShell)
```powershell
cd ai-poc-doc-search
py -3 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m streamlit run app.py     # http://127.0.0.1:8501
python -m pytest                   # 브라우저 테스트는 playwright 없으면 자동 건너뜀
```

## 구현/검증 구분
- 구현·테스트 통과: 3개 저장소 Connector, 다중 UNC 공유 등록, PDF/Excel/PPT 위치 추출, 통합 검색·필터·정렬, 사용자별 권한(캐시·이전 답변 재검증), 색인 갱신, 원문 미리보기·경로 복사
- Mock만 구현: AI 답변 모드 (실제 생성형 AI 연결 없음)
- 미구현/미검증: 실제 SMB·그룹웨어·업무시스템·SSO 연동, 자동 스케줄러, 스캔 PDF(OCR), Windows PC 실제 실행
